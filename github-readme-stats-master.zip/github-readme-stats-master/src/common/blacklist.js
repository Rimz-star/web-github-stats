const blacklist = [
  "renovate-bot",
  "technote-space",
  "sw-yx",
  "YourUsername",
  "[YourUsername]",
];

export { blacklist };
export default blacklist;
